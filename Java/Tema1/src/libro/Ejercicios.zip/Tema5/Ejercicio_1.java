package libro.Tema5;

public class Ejercicio_1 {
	public static void main(String[] args) {
		int numero = 5, multiplo;
		for (int i = 1; i <= 20; i++) {
			multiplo = numero * i;
			System.out.println(multiplo);
		}
	}
}
