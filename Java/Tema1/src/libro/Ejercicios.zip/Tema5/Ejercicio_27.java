package libro.Tema5;

public class Ejercicio_27 {

	public static void main(String[] args) {
		
	}

}
