package libro.Tema5;

public class Ejercicio_4 {
	public static void main(String[] args) {
		int empieza = 320, acaba = 160, i;
		for (i = empieza; i >= acaba; i -=20) {
			System.out.println(i);
		}
	}
}
