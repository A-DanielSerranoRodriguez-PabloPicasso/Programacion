package libro.Tema2;

public class Ejercicio_7 {

	public static void main(String[] args) {
		char letra = 'D';
		String palabra = "aniel";
		System.out.println(letra + palabra);
	}

}
