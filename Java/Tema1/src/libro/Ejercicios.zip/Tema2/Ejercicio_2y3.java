package libro.Tema2;

public class Ejercicio_2y3 {

	public static void main(String[] args) {
		String nombre = "Daniel";
		String direccion = "Calle 13";
		int tlfn = 123456789;
		
		System.out.printf("Tu nombre es: %s\nVives en: %s\nTu teléfono es: %d", nombre, direccion, tlfn);
	}

}
