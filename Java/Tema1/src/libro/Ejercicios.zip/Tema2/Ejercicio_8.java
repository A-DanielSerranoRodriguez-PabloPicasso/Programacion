package libro.Tema2;

public class Ejercicio_8 {

	public static void main(String[] args) {
		char letra1 = 'D', letra2 = 'A', letra3 = 'N', letra4 = 'I', letra5 = 'E';
		String palabra = String.valueOf(letra1) + String.valueOf(letra2) + String.valueOf(letra3) + String.valueOf(letra4) + String.valueOf(letra5);
		System.out.println(palabra);
	}

}
