package libro.Tema1;

public class Ejercicio_4y5 {

	public static void main(String[] args) {
		System.out.println(" ___________________________________________________________________");
		System.out.println("|           |            |               |            |             |");
		System.out.println("|           |            |               |            |             |");
		System.out.println("|   Lunes   |   Martes   |   Miércoles   |   Jueves   |   Viernes   |");
		System.out.println("|           |            |               |            |             |");
		System.out.println("|___________|____________|_______________|____________|_____________|");
		System.out.println("|           |            |               |            |             |");
		System.out.println("|    BBDD   |    SIST    |      FOL      |    BBDD    |     PROG    |");
		System.out.println("|___________|____________|_______________|____________|_____________|");
		System.out.println("|           |            |               |            |             |");
		System.out.println("|    BBDD   |    PROG    |      FOL      |    BBDD    |     PROG    |");
		System.out.println("|___________|____________|_______________|____________|_____________|");
		System.out.println("|           |            |               |            |             |");
		System.out.println("|    FOL    |    PROG    |      BBDD     |    SIST    |     PROG    |");
		System.out.println("|___________|____________|_______________|____________|_____________|");
		System.out.println("|                                                                   |");
		System.out.println("|                             RECREO                                |");
		System.out.println("|___________________________________________________________________|");
		System.out.println("|           |            |               |            |             |");
		System.out.println("|    PROG   |    EEDD    |      BBDD     |    SIST    |     SIST    |");
		System.out.println("|___________|____________|_______________|____________|_____________|");
		System.out.println("|           |            |               |            |             |");
		System.out.println("|    PROG   |    LLMM    |      LLMM     |    EEDD    |     SIST    |");
		System.out.println("|___________|____________|_______________|____________|_____________|");
		System.out.println("|           |            |               |            |             |");
		System.out.println("|    PROG   |    LLMM    |      LLMM     |    EEDD    |     SIST    |");
		System.out.println("|___________|____________|_______________|____________|_____________|");


	}

}
