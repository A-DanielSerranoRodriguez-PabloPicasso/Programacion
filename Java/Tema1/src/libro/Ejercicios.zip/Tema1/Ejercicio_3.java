package libro.Tema1;

public class Ejercicio_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] ingles = {"computer", "student", "cat", "penguin", "machine", "nature", "light", "green", "book", "pyramid"};
		String[] español = {"ordenador", "alumno/a", "gato", "pinguino", "máquina", "naturaleza", "luz", "verde", "libro", "pirámide"};
		for (int i = 0; i < español.length; i++) {
			System.out.println(ingles[i] + "\t" + español[i]);
		}
	}

}
