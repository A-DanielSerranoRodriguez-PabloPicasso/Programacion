package libro.Tema1;

public class Ejercicio_7y8 {

	public static void main(String[] args) {
		String punto = "*";
		System.out.println("    " + punto);
		System.out.println("   " + punto + " " + punto);
		System.out.println("  " + punto + "   " + punto);
		System.out.println(" " + punto + "     " + punto);
		System.out.println("*********");
		
		System.out.println("");
		
		System.out.println("*********");
		System.out.println(" " + punto + "     " + punto);
		System.out.println("  " + punto + "   " + punto);
		System.out.println("   " + punto + " " + punto);
		System.out.println("    " + punto);
	}

}
