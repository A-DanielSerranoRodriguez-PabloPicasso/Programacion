package libro.Tema1;
public class Ejercicio_6{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String punto = "*";
		for (int i = 0; i < 5; i++) {
			System.out.println(punto);
			punto += "**";
		}
	
	}
	
	
}