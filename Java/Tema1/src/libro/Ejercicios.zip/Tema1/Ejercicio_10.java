package libro.Tema1;

public class Ejercicio_10 {
	public static void main (String[] args) {
		System.out.println("Ofu, toma una montañita cutre");
		System.out.println("");
		System.out.println("                          @");
		System.out.println("                         @@@");
		System.out.println("                        @@@@@");
		System.out.println("                       @@@@@@@");
		System.out.println("                      @@@@@@@@@");
		System.out.println("#####################@@@@@@@@@@@##########################");
		System.out.println("####################@@@@@@@@@@@@@#########################");
		System.out.println("##########################################################");
		System.out.println("##########################################################");
		System.out.println("##########################################################");
		System.out.println("##########################################################");

	}
}
